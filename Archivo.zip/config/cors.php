<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Cross-Origin Resource Sharing (CORS) Configuration
    |--------------------------------------------------------------------------
    |
    | Configure the origins, methods and headers allowed for cross-origin
    | requests from the frontend.
    |
    */

    'paths' => ['api/*', 'sanctum/csrf-cookie'],

    'allowed_methods' => ['*'],

    'allowed_origins' => [config('app.frontend_url')],

    'allowed_origins_patterns' => [
        '/^http:\/\/localhost:\d+$/',
        '/^https?:\/\/.*\.tr3slog\.com$/',
        '/^https?:\/\/(.*\.)?termocontroljb\.com$/',
        '/^https?:\/\/(.*\.)?tr3slog\.julls\.net$/',
    ],

    'allowed_headers' => ['*'],

    'exposed_headers' => [],

    'max_age' => 0,

    'supports_credentials' => false,

];
